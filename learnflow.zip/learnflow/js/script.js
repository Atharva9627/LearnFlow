const courses = [
    { id: 1, title: "Neural Networks 101", category: "Data", progress: 80 },
    { id: 2, title: "Advanced React Patterns", category: "Dev", progress: 45 },
    { id: 3, title: "UI/UX Motion Design", category: "Design", progress: 10 },
    { id: 4, title: "Cybersecurity Essentials", category: "Dev", progress: 0 }
];

document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();
    loadSection('dashboard');
    setupNav();
    setupTheme();
});

function setupNav() {
    document.querySelectorAll('.nav-links li').forEach(link => {
        link.addEventListener('click', () => {
            document.querySelector('.nav-links li.active').classList.remove('active');
            link.classList.add('active');
            loadSection(link.getAttribute('data-section'));
        });
    });
}

function setupTheme() {
    const themeBtn = document.getElementById('theme-toggle');
    themeBtn.addEventListener('click', () => {
        document.body.classList.toggle('light-theme');
        const isLight = document.body.classList.contains('light-theme');
        themeBtn.innerHTML = isLight ? '<i data-lucide="moon"></i>' : '<i data-lucide="sun"></i>';
        lucide.createIcons();
    });
}

function loadSection(section) {
    const container = document.getElementById('dynamic-area');
    document.getElementById('section-title').innerText = section.charAt(0).toUpperCase() + section.slice(1);
    
    container.classList.remove('fade-in');
    void container.offsetWidth; 
    container.classList.add('fade-in');

    // --- DASHBOARD SECTION ---
    if (section === 'dashboard') {
        container.innerHTML = `
            <div class="stats-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:20px;">
                <div class="stat-card" data-tilt><h3>4</h3><p>Active Courses</p></div>
                <div class="stat-card" data-tilt><h3>12</h3><p>Lessons Done</p></div>
                <div class="stat-card" data-tilt><h3>85%</h3><p>Avg. Score</p></div>
            </div>
            <h3 style="margin-top:2rem">Continue Learning</h3>
            <div class="course-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap:20px; margin-top:1rem;">
                ${courses.slice(0,2).map(c => renderSingleCourseCard(c)).join('')}
            </div>
        `;
    } 
    // --- COURSES SECTION ---
    else if (section === 'courses') {
        container.innerHTML = `
            <div class="course-grid" style="display:grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap:20px;">
                ${courses.map(c => renderSingleCourseCard(c)).join('')}
            </div>`;
    } 
    // --- ASSIGNMENTS SECTION ---
    else if (section === 'assignments') {
        container.innerHTML = `
            <div class="stat-card" style="max-width: 600px">
                <h3>Current Project: React Dashboard</h3>
                <p style="color:var(--text-dim); margin: 15px 0;">Upload your .zip file containing the project source code.</p>
                <div style="border: 2px dashed var(--glass-border); padding: 40px; text-align: center; border-radius: 15px;">
                    <i data-lucide="upload-cloud" style="margin-bottom:10px"></i>
                    <p>Drag and drop or click to upload</p>
                    <input type="file" id="assign-upload" style="display:none">
                    <button class="btn-primary" style="width:auto; margin-top:15px; padding: 10px 30px;" onclick="document.getElementById('assign-upload').click()">Select File</button>
                </div>
            </div>`;
    } 
    // --- QUIZ SECTION ---
    else if (section === 'quiz') {
        container.innerHTML = `
            <div class="stat-card" style="max-width: 600px; margin: 0 auto;">
                <h3 style="margin-bottom: 10px;">Daily Knowledge Check</h3>
                <p style="margin-bottom:20px; color:var(--text-dim)">Topic: JavaScript Closures</p>
                
                <div class="quiz-box" style="display: flex; flex-direction: column; gap: 15px;">
                    <p style="font-size: 1.1rem; margin-bottom: 10px;">What is a closure in JavaScript?</p>
                    
                    <button class="quiz-option" onclick="handleQuiz(this, true)" 
                        style="background: rgba(255,255,255,0.05); border: 1px solid var(--glass-border); color: white; padding: 15px; border-radius: 12px; text-align: left; cursor: pointer; transition: 0.3s;">
                        A function bundled with its lexical environment
                    </button>
                    
                    <button class="quiz-option" onclick="handleQuiz(this, false)" 
                        style="background: rgba(255,255,255,0.05); border: 1px solid var(--glass-border); color: white; padding: 15px; border-radius: 12px; text-align: left; cursor: pointer; transition: 0.3s;">
                        A way to close the browser tab or window
                    </button>
                    
                    <button class="quiz-option" onclick="handleQuiz(this, false)" 
                        style="background: rgba(255,255,255,0.05); border: 1px solid var(--glass-border); color: white; padding: 15px; border-radius: 12px; text-align: left; cursor: pointer; transition: 0.3s;">
                        A method to delete variables from memory
                    </button>
                </div>
                
                <div id="quiz-feedback" style="margin-top: 20px; font-weight: 600; min-height: 24px;"></div>
            </div>`;
    }
    // --- PROFILE SECTION ---
    else if (section === 'profile') {
        container.innerHTML = `
            <div class="stat-card" style="max-width: 500px; text-align: center;">
                <div class="avatar" style="width:120px; height:120px; margin: 0 auto 20px;"></div>
                <h2>Alex Rivera</h2>
                <p style="color:var(--primary)">Premium Learner</p>
                <div style="display:flex; justify-content:space-around; margin-top:30px; border-top:1px solid var(--glass-border); padding-top:20px;">
                    <div><h4>12</h4><p style="font-size:0.8rem">Courses</p></div>
                    <div><h4>5</h4><p style="font-size:0.8rem">Certificates</p></div>
                    <div><h4>1.2k</h4><p style="font-size:0.8rem">Points</p></div>
                </div>
            </div>`;
    }

    lucide.createIcons();
    VanillaTilt.init(document.querySelectorAll("[data-tilt]"), { max: 10, speed: 400, glare: true, "max-glare": 0.1 });
}

// Helper function to keep code clean
function renderSingleCourseCard(c) {
    return `
        <div class="course-card" data-tilt>
            <small style="color:var(--primary)">${c.category}</small>
            <h3 style="margin:10px 0">${c.title}</h3>
            <div class="progress-container"><div class="progress-bar" style="width:${c.progress}%"></div></div>
            <button class="btn-primary" onclick="openVideo('${c.title}', ${c.progress})">${c.progress > 0 ? 'Continue' : 'Enroll'}</button>
        </div>
    `;
}
function openVideo(title, progress) {
    const modal = document.getElementById('video-modal');
    document.getElementById('modal-title').innerText = title;
    document.getElementById('modal-progress').style.width = progress + '%';
    modal.style.display = 'flex';
}

document.querySelector('.close-modal').onclick = () => {
    document.getElementById('video-modal').style.display = 'none';
};
function handleQuiz(element, isCorrect) {
    // Reset all options in this quiz
    const options = document.querySelectorAll('.quiz-option');
    options.forEach(opt => {
        opt.style.background = 'rgba(255,255,255,0.05)';
        opt.style.borderColor = 'var(--glass-border)';
    });

    const feedback = document.getElementById('quiz-feedback');
    
    if (isCorrect) {
        element.style.background = 'rgba(16, 185, 129, 0.2)'; // Green tint
        element.style.borderColor = '#10b981';
        feedback.innerText = "Correct! You've earned +10 points. 🎉";
        feedback.style.color = "#10b981";
    } else {
        element.style.background = 'rgba(239, 68, 68, 0.2)'; // Red tint
        element.style.borderColor = '#ef4444';
        feedback.innerText = "Not quite. Try reading the lesson again!";
        feedback.style.color = "#ef4444";
    }
}